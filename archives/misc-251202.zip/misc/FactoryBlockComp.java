package heavyindustry.world.misc;

import arc.math.Mathf;
import arc.scene.ui.layout.Table;
import arc.struct.OrderedMap;
import arc.struct.Seq;
import arc.util.io.Reads;
import arc.util.io.Writes;
import heavyindustry.world.misc.cons.BaseConsumers;
import heavyindustry.world.misc.producers.BaseProducers;
import mindustry.gen.Building;
import mindustry.graphics.Pal;
import mindustry.type.Item;
import mindustry.world.meta.Stat;
import mindustry.world.meta.StatCat;
import mindustry.world.meta.StatValue;
import mindustry.world.meta.Stats;

/**
 * Factory block component, describing some necessary attributes in {@linkplain FactoryBuildComp Factory Building}.
 *
 * @author EBwilson
 * @since 1.4
 */
public interface FactoryBlockComp extends ProducerBlockComp {
	/**
	 * The thermal efficiency of the block, interpolated from 0-1, is the speed of the block from startup to
	 * maximum efficiency, which is the interpolation of {@link arc.math.Mathf#lerpDelta(float, float, float)}.
     */
	float warmupSpeed(); // warmupSpeed

	/**
	 * The cooling rate of the block, interpolated from 0-1, is the speed at which the block completely
	 * stops. This is the interpolation of {@link arc.math.Mathf#lerpDelta(float, float, float)}.
	 */
	float stopSpeed(); // stopSpeed

	static void buildRecipe(Table table, BaseConsumers consumers, BaseProducers producers) {
		Stats stats = new Stats();

		if (consumers != null) {
			consumers.display(stats);
		}
		if (producers != null) {
			producers.display(stats);
		}

		buildStatTable(table, stats);
	}

	static void buildStatTable(Table table, Stats stat) {
		for (StatCat cat : stat.toMap().keys()) {
			OrderedMap<Stat, Seq<StatValue>> map = stat.toMap().get(cat);
			if (map.size == 0) continue;

			if (stat.useCategories) {
				table.add("@category." + cat.name).color(Pal.accent).fillX();
				table.row();
			}

			for (Stat state : map.keys()) {
				table.table(inset -> {
					inset.left();
					inset.add("[lightgray]" + state.localized() + ":[] ").left();
					Seq<StatValue> arr = map.get(state);
					for (StatValue value : arr) {
						value.display(inset);
						inset.add().size(10f);
					}
				}).fillX().padLeft(10);
				table.row();
			}
		}
	}

	/**
	 * The interface component of the factory building, which endows blocks with the behavior of
	 * production/manufacturing. The factory behavior integrates the behaviors of
	 * {@link ConsumerBuildComp} and {@link ProducerBlockComp} and describes the default implementation of
	 * manufacturing behavior.
	 *
	 * @author EBwilson
	 * @since 1.4
	 */
	interface FactoryBuildComp extends ProducerBuildComp {
		/** {@code getter-}production progress. */
		float progress(); // progress

		/** {@code setter-}production progress. */
		void progress(float value); // progress

		/** {@code getter-}Overall production progress. */
		float totalProgress(); // totalProgress

		/** {@code setter-}Overall production progress. */
		void totalProgress(float value); // totalProgress

		/** {@code getter-}Interpolation for preheating work. */
		float warmup(); // warmup

		/** {@code setter-}Interpolation for preheating work. */
		void warmup(float value); // warmup

		@Override
		default float consEfficiency() {
			return ProducerBuildComp.super.consEfficiency() * warmup();
		}

		// entryMethod = update
		default void updateFactory() {
			// Do not update when no formula is selected.
			if (produceCurrent() == -1 || producer().current == null) {
				warmup(Mathf.lerpDelta(warmup(), 0, getFactoryBlock().stopSpeed()));
				return;
			}

			if (shouldConsume() && consumeValid()) {
				progress(progress() + progressIncrease(consumer().current.craftTime));
				warmup(Mathf.lerpDelta(warmup(), 1, getFactoryBlock().warmupSpeed()));

				onCraftingUpdate();
			} else {
				warmup(Mathf.lerpDelta(warmup(), 0, getFactoryBlock().stopSpeed()));
			}

			totalProgress(totalProgress() + consumer().consDelta());

			while (progress() >= 1) {
				progress(progress() - 1);
				consumer().trigger();
				producer().trigger();

				craftTrigger();
			}
		}

		/**
		 * To process production, when the output is a building, it is necessary to correctly count the
		 * output items. When the factory handles the item and passes it in, the added item will be added
		 * to the statistics.
		 */
		// entryMethod = handleItem, paramTypes = {mindustry.gen.Building -> source, mindustry.type.Item -> item}
		default void handleProductItem(Building source, Item item) {
			if (source == this) {
				source.produced(item);
			}
		}

		// entryMethod = read, paramTypes = {arc.util.io.Reads -> read, byte}
		default void readFactory(Reads read) {
			progress(read.f());
			totalProgress(read.f());
			warmup(read.f());
		}

		// entryMethod = write, paramTypes = arc.util.io.Writes -> write
		default void writeFactory(Writes write) {
			write.f(progress());
			write.f(totalProgress());
			write.f(warmup());
		}

		/** The current working efficiency of the machine, 0-1. */
		default float workEfficiency() {
			return consEfficiency();
		}

		/**
		 * The sales increment of machine operation, under standard circumstances, is the reciprocal of
		 * production time, multiplied by the additional increment to return.
		 *
		 * @param baseTime The benchmark time consumption for the current execution
		 */
		default float progressIncrease(float baseTime) {
			return 1 / baseTime * consumer().consDelta();
		}

		default FactoryBlockComp getFactoryBlock() {
			return getBlock(FactoryBlockComp.class);
		}

		@Override
		default boolean shouldConsume() {
			return ProducerBuildComp.super.shouldConsume() && productValid();
		}

		/** Called during a production execution in machine operation. */
		void craftTrigger();

		/** Every refresh call during machine operation. */
		void onCraftingUpdate();
	}
}
