package heavyindustry.world.misc.modules;

import arc.math.Mathf;
import arc.util.io.Reads;
import arc.util.io.Writes;
import heavyindustry.world.misc.ProducerBlockComp.ProducerBuildComp;
import heavyindustry.world.misc.producers.BaseProduce;
import heavyindustry.world.misc.producers.BaseProducers;
import heavyindustry.world.misc.producers.ProduceType;
import mindustry.world.modules.BlockModule;

import java.util.List;

/**
 * Producer's output module, used for centralized processing of block production work.
 *
 * @author EBwilson
 */
public class BaseProductModule extends BlockModule {
	public BaseConsumeModule consumer;

	public final ProducerBuildComp entity;
	public BaseProducers current;
	public boolean valid;

	public BaseProductModule(ProducerBuildComp entity) {
		this.entity = entity;
		consumer = entity.consumer();
		current = entity.produceCurrent() != -1 ? entity.getProducerBlock().producers().get(entity.produceCurrent()) : null;
	}

	public List<BaseProducers> get() {
		return entity.getProducerBlock().producers();
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	public void trigger() {
		if (current != null) for (BaseProduce prod : current.all()) {
			prod.produce(entity.getBuilding(ProducerBuildComp.class));
		}
	}

	@SuppressWarnings("unchecked")
	public float getPowerProduct() {
		if (current == null) return 0;
		return current.get(ProduceType.power).powerProduction * entity.consumer().powerOtherEff * (Mathf.num(entity.shouldConsume() && entity.consumeValid()) * ((BaseProduce<ProducerBuildComp>) current.get(ProduceType.power)).multiple(entity));
	}

	public void setCurrent() {
		current = entity.consumeCurrent() == -1 ? null : get().get(entity.consumeCurrent());
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	public void update() {
		setCurrent();

		valid = true;
		// Output update only occurs when the production list is selected.
		if (current != null) {
			setCurrent();
			boolean doprod = entity.consumeValid() && entity.shouldConsume() && entity.shouldProduct();
			boolean preValid = valid();

			boolean anyValid = false;
			for (BaseProduce prod : current.all()) {
				boolean v = prod.valid(entity.getBuilding(ProducerBuildComp.class));
				anyValid |= v;
				valid &= !prod.blockWhenFull || v;
				if (doprod && preValid && v) {
					prod.update(entity.getBuilding(ProducerBuildComp.class));
				}
			}
			if (!anyValid) valid = false;
		}

		// Export products externally at all times.
		doDump(entity);
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	public void doDump(ProducerBuildComp entity) {
		if (current != null) {
			for (BaseProduce prod : current.all()) {
				prod.dump(entity.getBuilding(ProducerBuildComp.class));
			}
		}
	}

	public boolean valid() {
		return valid && entity.getBuilding().enabled;
	}

	@Override
	public void write(Writes write) {
		write.bool(valid);
	}

	@Override
	public void read(Reads read) {
		valid = read.bool();
	}
}
