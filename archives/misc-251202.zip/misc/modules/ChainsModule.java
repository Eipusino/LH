package heavyindustry.world.misc.modules;

import arc.func.Cons;
import arc.util.Eachable;
import arc.util.io.Writes;
import heavyindustry.util.comp.ExtraVariablec;
import heavyindustry.world.misc.ChainsBlockComp.ChainsBuildComp;
import heavyindustry.world.misc.chains.ChainsContainer;
import mindustry.world.modules.BlockModule;

import java.util.Map;

public class ChainsModule extends BlockModule implements Eachable<ChainsBuildComp>, ExtraVariablec {
	public ChainsBuildComp entity;
	public ChainsContainer container;

	public ChainsModule(ChainsBuildComp entity) {
		this.entity = entity;
	}

	public ChainsContainer newContainer() {
		ChainsContainer old = entity.chains().container;

		entity.chains().container = new ChainsContainer();
		entity.containerCreated(old);

		entity.chains().container.add(entity);

		return entity.chains().container;
	}

	@Override
	public void each(Cons<? super ChainsBuildComp> cons) {
		for (ChainsBuildComp other : container.all) {
			cons.get(other);
		}
	}

	@Override
	public Map<String, Object> extra() {
		return container.extra();
	}

	/**
	 * @see ChainsModule#setVar(String, Object)
	 * @deprecated Please use setVar(String, Object)
	 */
	@Deprecated
	public void putVar(String key, Object obj) {
		container.setVar(key, obj);
	}

	@Override
	public void write(Writes write) {}
}
