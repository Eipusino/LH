package heavyindustry.world.misc;

import arc.math.geom.Point2;
import heavyindustry.util.DirEdges;

/**
 * Building components for splicing blocks, record some necessary attributes for {@linkplain SpliceBuildComp splicing block building}.
 * <p><strong>This is an unstable API that may be adjusted to a more universal and efficient form in the future,
 * which may cause API changes. Please use it with caution.</strong>
 *
 * @author EBwilson
 * @since 1.5
 */
public interface SpliceBlockComp extends ChainsBlockComp {
	boolean interCorner(); // interCorner

	boolean negativeSplice(); // negativeSplice

	/**
	 * Building components that splice blocks to automatically synchronize the status of surrounding
	 * blocks and record them, typically used to draw continuous connecting materials for blocks.
	 * <p><strong>This is an unstable API that may be adjusted to a more universal and efficient form in the future,
	 * which may cause API changes. Please use it with caution</strong>
	 *
	 * @author EBwilson
	 * @since 1.5
	 */
	interface SpliceBuildComp extends ChainsBuildComp {
		int splice(); // splice

		void splice(int arr); // splice

		default int getSplice() {
			int result = 0;

			t:
			for (int i = 0; i < 8; i++) {
				SpliceBuildComp other = null;
				for (Point2 p : DirEdges.get8(getBlock().size, i)) {
					if (other == null) {
						if (getBuilding().nearby(p.x, p.y) instanceof SpliceBuildComp oth && oth.chains().container == chains().container) {
							other = oth;
						} else {
							continue t;
						}
					} else if (other != getBuilding().nearby(p.x, p.y)) {
						continue t;
					}
				}
				result |= 1 << i;
			}

			return result;
		}

		// entryMethod = onProximityUpdate
		default void updateRegionBit() {
			splice(getSplice());
		}
	}
}
