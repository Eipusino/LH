package heavyindustry.world.misc;

import arc.func.Boolf;
import arc.struct.Seq;
import mindustry.gen.Building;

import java.util.Map;

/**
 * This interface provides the implementer with the ability to sequentially extract (or predict the extraction
 * of) elements from a pile of elements.
 *
 * @author EBwilson
 * @since 1.2
 */
public interface Takeable extends BuildCompBase {
	Map<String, Heaps<?>> heaps(); // value = heaps, initialize = new arc.struct.ObjectMap()

	/**
	 * Adding an output element heap, initializing it with a string name and a Seq container, is not
	 * absolutely necessary.
	 *
	 * @param name    Heap naming, used for indexing
	 * @param targets All heap elements, select operations within them
	 */
	default void addHeap(String name, Seq<?> targets) {
		heaps().put(name, new Heaps<>(targets));
	}

	/**
	 * Adding an output element heap with a string as the name and a Seq container, as well as initializing
	 * a filter function that returns a Boolean value, is not absolutely necessary.
	 *
	 * @param name    Heap naming, used for indexing
	 * @param targets All heap elements, select operations within them
	 * @param valid   Select filter
	 */
	default <T> void addHeap(String name, Seq<T> targets, Boolf<T> valid) {
		heaps().put(name, new Heaps<>(targets, valid));
	}

	/**
	 * Get an output element heap
	 *
	 * @param name Name saved in the container
	 */
	@SuppressWarnings("unchecked")
	default <T> Heaps<T> getHeaps(String name) {
		return (Heaps<T>) heaps().get(name);
	}

	/**
	 * Retrieve the next element from the heap with the specified name. If the specified heap does not exist, a new heap will be created and added to the container.
	 *
	 * @param name Heap name
	 */
	default Building getNext(String name) {
		return getNext(name, true);
	}

	/**
	 * Retrieve the next element from the heap with the specified name. If the specified heap does not exist, a new heap will be created and added to the container.
	 *
	 * @param name    Heap name
	 * @param targets Provide a list of elements in the heap
	 */
	default <T> T getNext(String name, Seq<T> targets) {
		return getNext(name, targets, true);
	}

	/**
	 * Retrieve the next element from the heap with the specified name. If the specified heap does not
	 * exist, a new heap will be created and added to the container. The elements of the heap will default
	 * to {@link Building#proximity} from building.
	 *
	 * @param name  Heap name
	 * @param valid Element filter
	 */
	default Building getNext(String name, Boolf<Building> valid) {
		return getNext(name, valid, true);
	}

	/**
	 * Retrieve the next element from the heap with the specified name. If the specified heap does not
	 * exist, a new heap will be created and added to the container.
	 *
	 * @param name    Heap name
	 * @param targets Provide a list of elements in the heap
	 * @param valid   Element filter
	 */
	default <T> T getNext(String name, Seq<T> targets, Boolf<T> valid) {
		return getNext(name, targets, valid, true);
	}

	/**
	 * Predict the next element to be obtained. If the specified heap does not exist, a new heap will be
	 * created and added to the container. The elements of the heap will default to {@link Building#proximity}
	 * from building.
	 *
	 * @param name Heap name
	 */
	default Building peek(String name) {
		return getNext(name, false);
	}

	/**
	 * Predict the next element to be obtained, and if the specified heap does not exist, create a new heap
	 * and add it to the container.
	 *
	 * @param name    Heap name
	 * @param targets Provide a list of elements in the heap
	 */
	default <T> T peek(String name, Seq<T> targets) {
		return getNext(name, targets, false);
	}

	/**
	 * Predict the next element to be obtained. If the specified heap does not exist, a new heap will be
	 * created and added to the container. The elements of the heap will default to {@link Building#proximity}
	 * from building.
	 *
	 * @param name  Heap name
	 * @param valid Element filter
	 */
	default Building peek(String name, Boolf<Building> valid) {
		return getNext(name, valid, false);
	}

	/**
	 * 预测下一个获得的元素，如果指定的堆不存在，会创建一个新的堆加入容器
	 *
	 * @param name    Heap name
	 * @param targets Provide a list of elements in the heap
	 * @param valid   Element filter
	 */
	default <T> T peek(String name, Seq<T> targets, Boolf<T> valid) {
		return getNext(name, targets, valid, false);
	}

	/**
	 * Retrieve the next element from the heap with the specified name. If the specified heap does not
	 * exist, a new heap will be created and added to the container. The elements of the heap will default
	 * to {@link Building#proximity} from building.
	 *
	 * @param name     Heap name
	 * @param increase Do you want to increase the counter once? If false, this method is used to
	 *                 predict the next element
	 */
	@SuppressWarnings("unchecked")
	default Building getNext(String name, boolean increase) {
		Heaps<Building> heaps;
		if ((heaps = (Heaps<Building>) heaps().get(name)) == null) {
			heaps = new Heaps<>(getBuilding().proximity);
			heaps().put(name, heaps);
		}
		return increase ? heaps.next() : heaps.peek();
	}

	/**
	 * Retrieve the next element from the heap with the specified name. If the specified heap does not
	 * exist, a new heap will be created and added to the container. The elements of the heap will default
	 * to {@link Building#proximity} from building.
	 *
	 * @param name     Heap name
	 * @param valid    Element filter
	 * @param increase Do you want to increase the counter once? If false, this method is used to
	 *                 predict the next element
	 */
	@SuppressWarnings("unchecked")
	default Building getNext(String name, Boolf<Building> valid, boolean increase) {
		Heaps<Building> heaps;
		if ((heaps = (Heaps<Building>) heaps().get(name)) == null) {
			heaps = new Heaps<>(getBuilding().proximity, valid);
			heaps().put(name, heaps);
		}
		return increase ? heaps.next(valid) : heaps.peek(valid);
	}

	/**
	 * Retrieve the next element from the heap with the specified name. If the specified heap does not
	 * exist, a new heap will be created and added to the container.
	 *
	 * @param name     Heap name
	 * @param targets  Provide a list of elements in the heap
	 * @param increase Do you want to increase the counter once? If false, this method is used to
	 *                 predict the next element
	 */
	@SuppressWarnings("unchecked")
	default <T> T getNext(String name, Seq<T> targets, boolean increase) {
		Heaps<T> heaps;
		if ((heaps = (Heaps<T>) heaps().get(name)) == null) {
			heaps = new Heaps<>(targets);
			heaps().put(name, heaps);
		}
		return increase ? heaps.next(targets) : heaps.peek(targets);
	}

	/**
	 * Retrieve the next element from the heap with the specified name. If the specified heap does not
	 * exist, a new heap will be created and added to the container.
	 *
	 * @param name     Heap name
	 * @param targets  Provide a list of elements in the heap
	 * @param valid    Element filter
	 * @param increase Do you want to increase the counter once? If false, this method is used to
	 *                 predict the next element
	 */
	@SuppressWarnings("unchecked")
	default <T> T getNext(String name, Seq<T> targets, Boolf<T> valid, boolean increase) {
		Heaps<T> heaps;
		if ((heaps = (Heaps<T>) heaps().get(name)) == null) {
			heaps = new Heaps<>(targets, valid);
			heaps().put(name, heaps);
		}
		return increase ? heaps.next(targets, valid) : heaps.peek(targets, valid);
	}

	/** Element heap, used to save and count the target elements that pop up. */
	class Heaps<T> {
		public Seq<T> targets = new Seq<>();
		public Boolf<T> valid = e -> true;
		public int heapCounter;

		public Heaps() {}

		public Heaps(Seq<T> defaultAll) {
			this.targets = defaultAll;
		}

		public Heaps(Seq<T> targets, Boolf<T> valid) {
			this.targets = targets;
			this.valid = valid;
		}

		public int increaseCount(int size) {
			heapCounter = (heapCounter + 1) % size;
			return heapCounter;
		}

		public void setTargets(Seq<T> other) {
			targets = other;
		}

		public void setValid(Boolf<T> other) {
			valid = other;
		}

		public T next() {
			return next(targets, valid);
		}

		public T peek() {
			return peek(targets, valid);
		}

		public T next(Boolf<T> valid) {
			return next(targets, valid);
		}

		public T peek(Boolf<T> valid) {
			return peek(targets, valid);
		}

		public T next(Seq<T> targets) {
			return next(targets, valid);
		}

		public T peek(Seq<T> targets) {
			return peek(targets, valid);
		}

		public T next(Seq<T> targets, Boolf<T> valid) {
			int size = targets.size;
			if (size == 0) return null;
			T result;
			for (T ignored : targets) {
				result = targets.get(increaseCount(size));
				if (valid.get(result)) return result;
			}
			return null;
		}

		public T peek(Seq<T> targets, Boolf<T> valid) {
			int size = targets.size, curr = heapCounter;
			if (size == 0) return null;
			T result;
			for (T ignored : targets) {
				curr = (curr + 1) % size;
				result = targets.get(curr);
				if (valid.get(result)) return result;
			}
			return null;
		}
	}
}
