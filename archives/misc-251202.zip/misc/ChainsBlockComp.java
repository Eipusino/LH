package heavyindustry.world.misc;

import arc.func.Cons;
import arc.struct.IntSet;
import arc.util.Eachable;
import arc.util.io.Reads;
import arc.util.io.Writes;
import heavyindustry.util.CollectionList;
import heavyindustry.world.meta.HStat;
import heavyindustry.world.misc.chains.ChainsContainer;
import heavyindustry.world.misc.modules.ChainsModule;
import mindustry.gen.Building;
import mindustry.gen.Posc;
import mindustry.world.meta.Stats;

import java.util.Iterator;
import java.util.List;

/**
 * The block information component of the chain block, used for blocks, provides necessary descriptive
 * properties for {@linkplain ChainsBuildComp chain building}.
 *
 * @author EBwilson
 * @since 1.5
 */
public interface ChainsBlockComp {
	/** The maximum x-axis span of a continuous structure */
	int maxWidth(); // maxChainsWidth

	/** The maximum y-axis span of a continuous structure */
	int maxHeight(); // maxChainsHeight

	/**
	 * Can this block form a continuous structure with the target block? Both blocks need to
	 * be linked to each other to form a continuous structure.
	 *
	 * @param other Target Block
	 */
	default boolean chainable(ChainsBlockComp other) {
		return getClass().isAssignableFrom(other.getClass());
	}

	// Set statistical data for blocks
	// entryMethod = setStats, context = stats -> stats
	default void setChainsStats(Stats stats) {
		stats.add(HStat.maxStructureSize, "@x@", maxWidth(), maxHeight());
	}

	/**
	 * The interface component of chain blocks, which provides the ability to perform certain behaviors
	 * when blocks are placed continuously, and adds triggers for changes that occur on a continuous
	 * structure of a block.
	 *
	 * @author EBwilson
	 * @since 1.5
	 */
	interface ChainsBuildComp extends BuildCompBase, Posc, Iterable<ChainsBuildComp>, Eachable<ChainsBuildComp> {
		CollectionList<ChainsBuildComp> tempSeq = new CollectionList<>(ChainsBuildComp.class);

		/**
		 * This is a foolish approach But there doesn't seem to be a good solution, in other words, it is
		 * used to maintain the original structure without changing it when reloading the archive.
		 */
		IntSet loadingInvalidPos(); // value = loadingInvalidPos, initialize = new arc.struct.IntSet()

		/**
		 * Chain structured containers are the core of continuous structure preservation and behavior
		 * triggering.
		 */
		ChainsModule chains(); // chains

		default ChainsBlockComp getChainsBlock() {
			return getBlock(ChainsBlockComp.class);
		}

		// entryMethod = onProximityAdded
		default void onChainsAdded() {
			for (ChainsBuildComp other : chainBuilds()) {
				if (loadingInvalidPos().contains(other.getTile().pos())) continue;
				if (canChain(other) && other.canChain(this)) other.chains().container.add(chains().container);
			}
			if (!loadingInvalidPos().isEmpty()) loadingInvalidPos().clear();
		}


		/**
		 * Can it form a continuous structure with the target building? Only when it can be connected to
		 * the target can it form a continuous structure.
		 *
		 * @param other 目标建筑
		 */
		default boolean canChain(ChainsBuildComp other) {
			if (!getChainsBlock().chainable(other.getChainsBlock())) return false;

			return chains().container.inlerp(this, other);
		}

		// entryMethod = onProximityRemoved
		default void onChainsRemoved() {
			chains().container.remove(this);
		}

		/**
		 * Get other chain blocks that this building can connect to. Note that this returns a shared
		 * container, please save a copy if needed.
		 */
		default List<ChainsBuildComp> chainBuilds() {
			tempSeq.clear();
			getBuilding().proximity.each(other -> {
				if (other instanceof ChainsBuildComp comp && canChain(comp) && comp.canChain(this)) {
					tempSeq.add(comp);
				}
			});
			return tempSeq;
		}

		/**
		 * Iterative implementation, this component can directly traverse all structural members through
		 * for each.
		 */
		@Override
		default Iterator<ChainsBuildComp> iterator() {
			return chains().container.all.iterator();
		}

		@Override
		default void each(Cons<? super ChainsBuildComp> cons) {
			chains().container.all.each(cons);
		}

		/**
		 * When a new {@linkplain ChainsContainer chain structure container} is created in this block, it is called.
		 *
		 * @param old Replaced original container
		 */
		default void containerCreated(ChainsContainer old) {}

		/**
		 * Called when this block is added to a chain structure
		 *
		 * @param old When added to a continuous structure, the current container of the block will
		 *            be replaced by the target container, and the original container that was replaced will be
		 *            passed in from this parameter
		 */
		default void chainsAdded(ChainsContainer old) {}

		/**
		 * Call when removing from {@linkplain ChainsContainer chain structure container} in this block
		 *
		 * @param children This block is linked to other surrounding blocks
		 */
		default void chainsRemoved(List<ChainsBuildComp> children) {}

		/**
		 * When a {@linkplain ChainsContainer} performs a traversal search and adds the block to the container, it is
		 * called.
		 *
		 * @param old When added to a continuous structure, the current container of the block will
		 *            be replaced by the target container, and the original container that was replaced will be
		 *            passed in from this parameter
		 */
		default void chainsFlowed(ChainsContainer old) {}

		/** Called <strong>after</strong> any part of the continuous structure changes. */
		default void onChainsUpdated() {}

		// entryMethod = write, paramTypes = arc.util.io.Writes -> write
		default void writeChains(Writes write) {
			tempSeq.clear();
			for (Building building : getBuilding().proximity) {
				if (building instanceof ChainsBuildComp chain && chain.chains().container != chains().container) {
					tempSeq.add(chain);
				}
			}

			write.i(tempSeq.size);
			tempSeq.each(comp -> write.i(comp.getTile().pos()));
		}

		// entryMethod = read, paramTypes = {arc.util.io.Reads -> read, byte}
		default void readChains(Reads read) {
			int size = read.i();
			for (int i = 0; i < size; i++) {
				loadingInvalidPos().add(read.i());
			}
		}
	}
}
