package heavyindustry.world.misc;

import arc.func.Cons2;
import arc.math.Mathf;
import arc.scene.ui.layout.Table;
import heavyindustry.world.misc.cons.BaseConsume;
import heavyindustry.world.misc.cons.BaseConsumers;
import heavyindustry.world.misc.cons.ConsFilter;
import heavyindustry.world.misc.cons.ConsumePower;
import heavyindustry.world.misc.cons.ConsumeType;
import heavyindustry.world.misc.modules.BaseConsumeModule;
import mindustry.world.Block;
import mindustry.world.meta.Stats;

import java.util.List;

/**
 * Consume component, adding the ability to mark consumable items to blocks.
 *
 * @author EBwilson
 * @since 1.0
 */
public interface ConsumerBlockComp {
	/** List of consumption of blocks. */
	List<BaseConsumers> consumers(); // value = consumers, initialize = new arc.struct.Seq<>()

	/** List of optional consumption options for blocks. */
	List<BaseConsumers> optionalCons(); // value = optionalCons, initialize = new arc.struct.Seq<>()

	/** Does this block only select the top option when consuming the optional list once. */
	boolean oneOfOptionCons(); // oneOfOptionCons

	ConsFilter filter(); // value = consFilter, initialize = new universecore.world.consumers.ConsFilter()

	/** Create a new consumption list, insert it into the container, and return it. */
	default BaseConsumers newConsume() {
		BaseConsumers consume = new BaseConsumers(false);
		consumers().add(consume);
		return consume;
	}

	/**
	 * Create an optional consumption list, insert it into the container, and return it.
	 *
	 * @param validDef   When this consumable item is available, the behavior to be performed each time it is refreshed
	 * @param displayDef Used to set statistical entries and display the optional consumption function
	 */
	@SuppressWarnings("unchecked")
	default <T extends ConsumerBuildComp> BaseConsumers newOptionalConsume(Cons2<T, BaseConsumers> validDef, Cons2<Stats, BaseConsumers> displayDef) {
		BaseConsumers consume = new BaseConsumers(true) {{
			optionalDef = (Cons2<ConsumerBuildComp, BaseConsumers>) validDef;
			display = displayDef;
		}};
		optionalCons().add(consume);
		return consume;
	}

	/*
	 * To add blocks to the energy network, it is necessary to initialize an existing energy consumer as a
	 * proxy, which is called by the {@link Block#init()} entry in componentized implementation.
	 */
	// entryMethod = init
	default void initPower() {
		Block block = (Block) this;

		if (block.consumesPower) {
			block.consumePowerDynamic(e -> {
				ConsumerBuildComp entity = (ConsumerBuildComp) e;
				if (entity.consumer().current == null) return 0f;
				if (entity.getBuilding().tile.build == null || entity.consumeCurrent() == -1 || !entity.consumer().excludeValid(ConsumeType.power))
					return 0f;

				ConsumePower<?> cons = entity.consumer().current.get(ConsumeType.power);
				if (cons == null) return 0;

				if (cons.buffered) {
					return (1f - entity.getBuilding().power.status) * cons.capacity;
				} else {
					return entity.consumer().getPowerUsage() * Mathf.num(entity.shouldConsume());
				}
			});
		}
	}

	// entryMethod = init
	default void initFilter() {
		filter().applyFilter(consumers(), optionalCons());
		for (BaseConsumers consumer : consumers()) {
			consumer.initFilter();
		}
	}

	/**
	 * Consumer components enable blocks to have the ability to consume and check resources.
	 *
	 * @author EBwilson
	 * @since 1.0
	 */
	interface ConsumerBuildComp extends BuildCompBase {
		/** Index of currently selected consumption items. */
		int consumeCurrent(); // consumeCurrent

		/** Obtain consumption module */
		BaseConsumeModule consumer(); // consumer

		// entryMethod = update
		default void updateConsumer() {
			consumer().update();
		}

		default float consMultiplier() {
			return 1;
		}

		/** Current consumption execution efficiency, from 0-1. */
		default float consEfficiency() {
			return consumer().consEfficiency;
		}

		default float optionalConsEff(BaseConsumers consumers) {
			return consumer().getOptionalEff(consumers);
		}

		/** Obtain the ConsumerBlock for this block. */
		default ConsumerBlockComp getConsumerBlock() {
			return getBlock(ConsumerBlockComp.class);
		}

		/** Obtain the NuclearEnergyBlock for this block. */
		default ConsumerBuildComp getConsumerBuilding() {
			return getBlock(ConsumerBuildComp.class);
		}

		/** Does the consumption condition of the current consumption list for this block meet. */
		default boolean consumeValid() {
			return consumer() == null || !consumer().hasConsume() || consumer().valid();
		}

		/** Should this block currently consume the consumption list. */
		default boolean shouldConsume() {
			return consumer() != null && consumeCurrent() != -1;
		}

		/** Should this block currently consume the optional consumption list. */
		default boolean shouldConsumeOptions() {
			return shouldConsume() && consumer().hasOptional();
		}

		@SuppressWarnings("unchecked")
		default void buildConsumerBars(Table bars) {
			if (consumer().current != null) {
				for (BaseConsume<? extends ConsumerBuildComp> consume : consumer().current.all()) {
					((BaseConsume<ConsumerBuildComp>) consume).buildBars(this, bars);
				}
			}
		}
	}
}
