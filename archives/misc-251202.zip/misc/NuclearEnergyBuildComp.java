package heavyindustry.world.misc;

import arc.math.Mathf;
import arc.scene.ui.layout.Table;
import arc.struct.Seq;
import heavyindustry.world.misc.modules.NuclearEnergyModule;
import mindustry.gen.Building;

/**
 * This interface indicates that this Building is a block with nuclear energy, and a {@link NuclearEnergyModule}
 * needs to be initialized in create.
 */
public interface NuclearEnergyBuildComp extends BuildCompBase, Takeable {
	Seq<NuclearEnergyBuildComp> tmp = new Seq<>(false, 16, NuclearEnergyBuildComp.class);

	boolean hasEnergy(); // hasEnergy

	float resident(); // resident

	float energyCapacity(); // energyCapacity

	boolean outputEnergy(); // outputEnergy

	boolean consumeEnergy(); // consumeEnergy

	float basicPotentialEnergy(); // basicPotentialEnergy

	float maxEnergyPressure(); // maxEnergyPressure

	/** The nuclear module used to obtain the block. */
	NuclearEnergyModule energy(); // energy

	Seq<NuclearEnergyBuildComp> energyLinked(); // value = energyLinked, initialize = new arc.struct.Seq<>(NuclearEnergyBuildComp.class)

	/** Display the nuclear panel or something else. */
	default void displayEnergy(Table table) {
		if (hasEnergy()) energy().display(table);
	}

	/**
	 * The method of operating nuclear energy usually directly refers to the handle method of
	 * EnergyModule.
	 */
	default void handleEnergy(float value) {
		energy().handle(value);
	}

	/**
	 * Transferring nuclear energy to a designated block, the speed depends on the potential energy
	 * difference.
	 */
	default float moveEnergy(NuclearEnergyBuildComp next) {
		if (!next.hasEnergy() || !next.acceptEnergy(this)) return 0;
		float rate = getEnergyMoveRate(next);

		if (rate > 0.01f) {
			float energyDiff = getEnergyPressure(next);
			if (energyDiff > next.maxEnergyPressure()) next.onOverpressure(energyDiff);

			handleEnergy(-rate);
			next.handleEnergy(rate);

			energyMoved(next, rate);
		}
		return rate;
	}

	default float getEnergyPressure(NuclearEnergyBuildComp other) {
		if (!other.hasEnergy()) return 0;
		return Mathf.maxZero(getOutputPotential() - other.getInputPotential() - other.basicPotentialEnergy());
	}

	// entryMethod = update, insert = HEAD
	default void updateEnergy() {
		if (hasEnergy()) energy().update();
	}

	/** Obtain the nuclear energy transmission speed of the block to the target block. */
	default float getEnergyMoveRate(NuclearEnergyBuildComp next) {
		if (!next.hasEnergy() || !next.acceptEnergy(this) || getOutputPotential() < next.getInputPotential()) return 0;
		float energyDiff = getEnergyPressure(next);

		float flowRate = (Math.min(energyDiff * energyDiff / 60, energyDiff) - next.getResident()) * getBuilding().delta();
		flowRate = Math.min(flowRate, next.energyCapacity() - next.getEnergy());
		flowRate = Math.min(flowRate, getEnergy());

		return Math.max(flowRate, 0);
	}

	default Seq<NuclearEnergyBuildComp> proximityNuclearBuilds() {
		tmp.clear();

		for (Building building : getBuilding().proximity) {
			if (building instanceof NuclearEnergyBuildComp n && n.hasEnergy()) {
				tmp.add(n);
			}
		}

		return tmp;
	}

	default float getEnergy() {
		return energy().getEnergy();
	}

	default float getInputPotential() {
		return energy().getEnergy();
	}

	default float getOutputPotential() {
		return energy().getEnergy();
	}

	default float getResident() {
		return resident();
	}

	/** Return whether the block accepts nuclear energy input. */
	default boolean acceptEnergy(NuclearEnergyBuildComp source) {
		return getBuilding().interactable(source.getBuilding().team) && hasEnergy() && energy().getEnergy() < energyCapacity();
	}

	default void dumpEnergy() {
		dumpEnergy(proximityNuclearBuilds());
	}

	/** Output nuclear energy to the connected block, if that block accepts it. */
	default void dumpEnergy(Seq<NuclearEnergyBuildComp> dumpTargets) {
		NuclearEnergyBuildComp dump = getNext("energy", dumpTargets, e -> {
			if (e == null || e == this) return false;
			return e.acceptEnergy(this) && getEnergyMoveRate(e) > 0;
		});
		if (dump != null) {
			moveEnergy(dump);
		}
	}

	default void energyMoved(NuclearEnergyBuildComp next, float rate) {}

	/**
	 * The method of triggering when overload can be suppressed.
	 *
	 * @param energyPressure The difference in nuclear potential energy between the blocks at this time
	 */
	void onOverpressure(float energyPressure);
}
