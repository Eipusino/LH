package heavyindustry.world.misc;

import arc.struct.ObjectMap;
import mindustry.world.Tile;

/**
 * The block component that can be replaced and placed over can transmit information when the block is
 * placed over, passing the old block to the new block.
 *
 * @author EBwilson
 * @since 1.5
 */
public interface ReplaceBuildComp extends BuildCompBase {
	ObjectMap<Tile, ReplaceBuildComp> replaceEntry = new ObjectMap<>();

	//entryMethod = onRemoved, insert = HEAD
	default void onRemoving() {
		Tile tile = getTile();
		replaceEntry.put(tile, this);
	}

	// entryMethod = init, paramTypes = {mindustry.world.Tile, mindustry.game.Team, boolean, int}
	default void buildInitialized() {
		ReplaceBuildComp old = replaceEntry.get(getTile());
		if (old == null) return;
		onReplaced(old);
		replaceEntry.remove(getTile());
	}

	/**
	 * Called when a valid replaceable block is placed and overlaid on a block, passing in the overwritten
	 * block.
	 *
	 * @param old The block originally located at this position
	 */
	void onReplaced(ReplaceBuildComp old);
}
