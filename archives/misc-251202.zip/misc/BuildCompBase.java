package heavyindustry.world.misc;

import mindustry.gen.Building;
import mindustry.world.Block;
import mindustry.world.Tile;
import mindustry.world.modules.ItemModule;
import mindustry.world.modules.LiquidModule;

/**
 * The basic interface of building components should actually use a build manager to construct buildings,
 * but Anuke's approach makes it difficult.
 *
 * @author EBwilson
 * @since 1.0
 */
public interface BuildCompBase {
	/**
	 * The generic check for obtaining building blocks requires the implementation class to be a subclass
	 * of {@link Building}.
	 *
	 * @param clazz Returned block type
	 */
	@SuppressWarnings("unchecked")
	default <T> T getBlock(Class<T> clazz) {
		Block block = getBuilding().block;
		if (clazz.isAssignableFrom(block.getClass())) {
			return (T) block;
		}
		return null;
	}

	/** Get the {@link Block} for this building. */
	default Block getBlock() {
		return getBlock(Block.class);
	}

	/**
	 * Get instances of the type with checked generics.
	 *
	 * @param clazz Return base class type
	 * @throws ClassCastException If the class containing the interface is not a subclass of {@link Building}
	 */
	@SuppressWarnings("unchecked")
	default <T> T getBuilding(Class<T> clazz) {
		if (clazz.isAssignableFrom(getClass())) return (T) this;
		throw new ClassCastException(getClass() + " cannot cast to " + clazz);
	}

	/**
	 * Get Building
	 *
	 * @throws ClassCastException If the class containing the interface is not a subclass of {@link Building}
	 */
	default Building getBuilding() {
		if (Building.class.isAssignableFrom(getClass())) return (Building) this;
		throw new ClassCastException(getClass() + " cannot cast to " + Building.class);
	}

	/** Retrieve instances of this type using unchecked generics. */
	@SuppressWarnings("unchecked")
	default <T> T getBuild() {
		return (T) this;
	}

	/** Get the tile of the build */
	Tile getTile(); // tile

	/** Get items module */
	ItemModule items(); // items

	/** Get liquids module */
	LiquidModule liquids(); // liquids
}
