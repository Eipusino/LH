package heavyindustry.world.misc;

import arc.scene.ui.layout.Table;
import mindustry.gen.Building;

/** A block component with a secondary configuration menu requires this interface when opening the secondary configuration for block configuration. */
public interface SecondableConfigBuildComp {
	/**
	 * Method for establishing a secondary configuration panel.
	 *
	 * @param table  Panel layout table, edit this list
	 * @param target Target building for secondary configuration
	 */
	void buildSecondaryConfig(Table table, Building target);
}
