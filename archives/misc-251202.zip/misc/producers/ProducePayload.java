package heavyindustry.world.misc.producers;

import arc.Events;
import arc.func.Boolf2;
import arc.func.Func2;
import arc.scene.ui.layout.Table;
import heavyindustry.util.CollectionObjectMap;
import heavyindustry.world.misc.ProducerBlockComp.ProducerBuildComp;
import heavyindustry.world.misc.cons.ConsumePayload;
import mindustry.ctype.UnlockableContent;
import mindustry.game.EventType;
import mindustry.gen.Building;
import mindustry.gen.Unit;
import mindustry.type.PayloadStack;
import mindustry.type.UnitType;
import mindustry.world.Block;
import mindustry.world.blocks.payloads.BuildPayload;
import mindustry.world.blocks.payloads.Payload;
import mindustry.world.blocks.payloads.UnitPayload;
import mindustry.world.meta.Stat;
import mindustry.world.meta.StatValues;
import mindustry.world.meta.Stats;

public class ProducePayload<T extends Building & ProducerBuildComp> extends BaseProduce<T> {
	private static final CollectionObjectMap<UnlockableContent, PayloadStack> TMP = new CollectionObjectMap<>(UnlockableContent.class, PayloadStack.class);

	public int displayLim = 4;
	public PayloadStack[] payloads;
	public Func2<T, UnlockableContent, Payload> payloadMaker = this::makePayloadDef;
	public Boolf2<T, UnlockableContent> valid;

	public ProducePayload(PayloadStack[] payloads, Boolf2<T, UnlockableContent> valid) {
		this.payloads = payloads;
		this.valid = valid;
	}

	private Payload makePayloadDef(T ent, UnlockableContent content) {
		if (content instanceof UnitType type) {
			Unit unit = type.create(ent.team);
			Events.fire(new EventType.UnitCreateEvent(unit, ent));
			return new UnitPayload(unit);
		} else if (content instanceof Block block) {
			return new BuildPayload(block, ent.team);
		} else {
			throw new IllegalArgumentException("default payload maker can only make 'Building' and 'Unit', if you want to make other things, please use custom payload maker to field 'payloadMaker'");
		}
	}

	@Override
	public ProduceType<?> type() {
		return ProduceType.payload;
	}

	@Override
	public void buildIcons(Table table) {
		ConsumePayload.buildPayloadIcons(table, payloads, displayLim);
	}

	@Override
	public void merge(BaseProduce<T> other) {
		if (other instanceof ProducePayload<?> prod) {
			TMP.clear();
			for (PayloadStack stack : payloads) {
				TMP.put(stack.item, stack);
			}

			for (PayloadStack stack : prod.payloads) {
				TMP.get(stack.item, () -> new PayloadStack(stack.item, 0)).amount += stack.amount;
			}

			payloads = TMP.values().toSeq().sort((a, b) -> a.item.id - b.item.id).toArray(PayloadStack.class);
		} else {
			throw new IllegalArgumentException("only merge consume with same type");
		}
	}

	@Override
	public void produce(T entity) {
		for (PayloadStack stack : payloads) {
			for (int i = 0; i < stack.amount; i++) {
				Payload payload = payloadMaker.get(entity, stack.item);
				payload.set(entity.x, entity.y, entity.rotdeg());
				if (entity.acceptPayload(entity, payload)) entity.handlePayload(entity, payload);
			}
		}
	}

	@Override
	public boolean valid(T entity) {
		for (PayloadStack stack : payloads) {
			if (!valid.get(entity, stack.item)) return false;
		}
		return true;
	}

	@Override
	public void update(T entity) {}

	@Override
	public void display(Stats stats) {
		for (PayloadStack stack : payloads) {
			stats.add(Stat.output, t -> {
				t.add(StatValues.stack(stack));
				t.add(stack.item.localizedName).padLeft(4).padRight(4);
			});
		}
	}
}
