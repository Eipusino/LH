package heavyindustry.world.misc.producers;

import heavyindustry.util.CollectionList;

@SuppressWarnings("unchecked")
public class ProduceType<T extends BaseProduce<?>> {
	private static final CollectionList<ProduceType<?>> allType = new CollectionList<>(ProduceType.class);

	public static final ProduceType<ProducePower<?>> power = (ProduceType<ProducePower<?>>) add(ProducePower.class);
	public static final ProduceType<ProduceItems<?>> item = (ProduceType<ProduceItems<?>>) add(ProduceItems.class);
	public static final ProduceType<ProduceLiquids<?>> liquid = (ProduceType<ProduceLiquids<?>>) add(ProduceLiquids.class);
	public static final ProduceType<ProducePayload<?>> payload = (ProduceType<ProducePayload<?>>) add(ProducePayload.class);

	private final int id;
	private final Class<T> type;

	public ProduceType(Class<T> type) {
		id = allType.size;
		this.type = type;
		allType.add(this);
	}

	public Class<T> getType() {
		return type;
	}

	public final int id() {
		return id;
	}

	public static ProduceType<?>[] all() {
		return allType.toArray();
	}

	public static <T extends BaseProduce<?>> ProduceType<? extends T> add(Class<T> type) {
		return new ProduceType<>(type);
	}
}
