package heavyindustry.world.misc.producers;

import arc.graphics.Color;
import heavyindustry.util.CollectionList;
import heavyindustry.util.CollectionObjectMap;
import heavyindustry.world.misc.cons.BaseConsumers;
import mindustry.type.Item;
import mindustry.type.ItemStack;
import mindustry.type.Liquid;
import mindustry.type.LiquidStack;
import mindustry.world.meta.Stats;

/**
 * Output list, bind a consumption list, and execute the corresponding production list while executing
 * consumption to achieve factory production.
 *
 * @author EBwilson
 */
public class BaseProducers {
	final static Color TRANS = new Color(0, 0, 0, 0);

	protected static final CollectionList<BaseProduce<?>> tmpProd = new CollectionList<>(BaseProduce.class);

	protected final CollectionObjectMap<ProduceType<?>, BaseProduce<?>> prod = new CollectionObjectMap<>(ProduceType.class, BaseProduce.class);

	/**
	 * The color of this production item is usually used to quickly select colors for purposes such as
	 * determining the top of the drawing.
	 */
	public Color color = TRANS;
	/**
	 * Post initialized variables should not be manually changed, as they are bound to consumption items
	 * that match this production.
	 */
	public BaseConsumers cons;

	public BaseProducers setColor(Color color) {
		this.color = color;
		return this;
	}

	public ProduceItems<?> item(Item item, int amount) {
		return items(new ItemStack(item, amount));
	}

	public ProduceItems<?> items(ItemStack... items) {
		return add(new ProduceItems<>(items));
	}

	public ProduceLiquids<?> liquid(Liquid liquid, float amount) {
		return liquids(new LiquidStack(liquid, amount));
	}

	public ProduceLiquids<?> liquids(LiquidStack... liquids) {
		return add(new ProduceLiquids<>(liquids));
	}

	public ProducePower<?> power(float prod) {
		return add(new ProducePower<>(prod));
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	public <T extends BaseProduce<?>> T add(T produce) {
		BaseProduce p = prod.get(produce.type());
		if (p == null) {
			prod.put(produce.type(), produce);
			produce.parent = this;
			if (color == TRANS && produce.color() != null) {
				color = produce.color();
			}
			return produce;
		} else p.merge(produce);
		return (T) p;
	}

	@SuppressWarnings("unchecked")
	public <T extends BaseProduce<?>> T get(ProduceType<T> type) {
		return (T) prod.get(type);
	}

	public Iterable<BaseProduce<?>> all() {
		tmpProd.clear();

		for (ProduceType<?> type : ProduceType.all()) {
			BaseProduce<?> p = prod.get(type);
			if (p != null) tmpProd.add(p);
		}

		return tmpProd;
	}

	public void remove(ProduceType<?> type) {
		prod.remove(type);
	}

	public void display(Stats stats) {
		if (prod.size > 0) {
			for (BaseProduce<?> p : prod.values().toSeq().sort((a, b) -> a.type().id() - b.type().id())) {
				p.display(stats);
			}
		}
	}
}
