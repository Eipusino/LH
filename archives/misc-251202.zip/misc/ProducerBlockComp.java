package heavyindustry.world.misc;

import arc.math.Mathf;
import arc.scene.ui.layout.Table;
import heavyindustry.world.misc.modules.BaseProductModule;
import heavyindustry.world.misc.producers.BaseProduce;
import heavyindustry.world.misc.producers.BaseProducers;
import heavyindustry.world.misc.producers.ProducePower;
import heavyindustry.world.misc.producers.ProduceType;

import java.util.List;

/**
 * The component of the producer block enables the block to have the function of recording and
 * outputting resource recipes.
 *
 * @author EBwilson
 * @since 1.0
 */
public interface ProducerBlockComp extends ConsumerBlockComp {
	/** List of Production Lists */
	List<BaseProducers> producers(); // value = producers, initialize = new arc.struct.Seq<>()

	/** Create a new production list, add it to the container, and return it. */
	default BaseProducers newProduce() {
		BaseProducers produce = new BaseProducers();
		producers().add(produce);
		return produce;
	}

	/** Initialize the matching consumption production list, and call it at the end of init() */
	// entryMethod = init
	default void initProduct() {
		int b = producers().size();
		int a = consumers().size();
		// Control the production of adding/removing recipes to synchronize the recipes
		while (a > b) {
			BaseProducers p = new BaseProducers();
			producers().add(p);
			b++;
		}
		while (a < b) {
			b--;
			producers().remove(b);
		}

		for (int index = 0; index < producers().size(); index++) {
			producers().get(index).cons = consumers().get(index);
		}
	}

	/**
	 * Producer component, which enables blocks to have the ability to produce and output resources on
	 * demand.
	 *
	 * @author EBwilson
	 * @since 1.0
	 */
	interface ProducerBuildComp extends BuildCompBase, ConsumerBuildComp {
		/** Index of the currently selected production project. */
		default int produceCurrent() {
			return consumeCurrent();
		}

		float powerProdEfficiency(); // powerProdEfficiency

		void powerProdEfficiency(float powerProdEfficiency); // powerProdEfficiency

		default float prodMultiplier() {
			return consMultiplier();
		}

		/** Production components. */
		BaseProductModule producer(); // producer

		// entryMethod = update
		default void updateProducer() {
			producer().update();
		}

		/** Obtain the NuclearEnergyBlock for this block. */
		default ProducerBlockComp getProducerBlock() {
			return getBlock(ProducerBlockComp.class);
		}

		/** Obtain the NuclearEnergyBlock for this block. */
		default ProducerBuildComp getProducerBuilding() {
			return getBlock(ProducerBuildComp.class);
		}

		/** Is the current production available. */
		default boolean productValid() {
			return producer() == null || producer().valid();
		}

		/** Should production item updates be executed at present. */
		default boolean shouldProduct() {
			return producer() != null && produceCurrent() != -1;
		}

		@SuppressWarnings("unchecked")
		default void buildProducerBars(Table bars) {
			if (consumer().current != null) {
				for (BaseProduce<? extends ProducerBuildComp> consume : producer().current.all()) {
					((BaseProduce<ProducerBuildComp>) consume).buildBars(this, bars);
				}
			}
		}

		@SuppressWarnings({"unchecked", "rawtypes"})
		// entryMethod = getPowerProduction, override = true
		default float getPowerProduction() {
			if (!getBlock().outputsPower || producer().current == null || producer().current.get(ProduceType.power) == null)
				return 0;
			powerProdEfficiency(Mathf.num(shouldConsume() && consumeValid()) * consEfficiency() * ((ProducePower) (producer().current.get(ProduceType.power))).multiple(this));
			return producer().getPowerProduct() * powerProdEfficiency();
		}
	}
}
