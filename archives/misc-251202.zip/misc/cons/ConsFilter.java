package heavyindustry.world.misc.cons;

import arc.func.Prov;
import heavyindustry.util.CollectionObjectMap;
import heavyindustry.util.CollectionObjectSet;
import heavyindustry.util.concurrent.holder.ObjectHolder;
import heavyindustry.world.misc.ConsumerBlockComp.ConsumerBuildComp;
import mindustry.ctype.Content;

import java.util.Set;

public class ConsFilter {
	public CollectionObjectMap<ConsumeType<?>, Set<Content>> optionalFilter = new CollectionObjectMap<>(ConsumeType.class, Set.class);
	public CollectionObjectMap<ConsumeType<?>, Set<Content>> allFilter = new CollectionObjectMap<>(ConsumeType.class, Set.class);

	public final Prov<Set<Content>> createSet = () -> new CollectionObjectSet<>(Content.class);

	public void applyFilter(Iterable<BaseConsumers> consumers, Iterable<BaseConsumers> optional) {
		if (optional != null) {
			for (BaseConsumers cons : optional) {
				handle(cons, optionalFilter);
				handle(cons, allFilter);
			}
		}

		if (consumers != null) {
			for (BaseConsumers cons : consumers) {
				handle(cons, allFilter);
				for (ObjectHolder<ConsumeType<?>, Set<Content>> access : cons.selfAccess) {
					allFilter.get(access.key, createSet);
				}
			}
		}
	}

	/**
	 * Filter, which will determine whether the input object is accepted under the specified type for the
	 * currently selected area.
	 * <p>If the optional filter has added the target object, return true.
	 *
	 * @param type      Filter type
	 * @param target    Target object through filter
	 * @param acceptAll Do you accept all the requirements on the list
	 * @return Boolean value, whether to accept this object or not
	 *
	 */
	public boolean filter(ConsumerBuildComp entity, ConsumeType<?> type, Content target, boolean acceptAll) {
		if (optionalFilter.containsKey(type) && optionalFilter.get(type).contains(target)) return true;

		if (acceptAll) return allFilter.containsKey(type) && allFilter.get(type).contains(target);

		return entity.consumer().current != null && entity.consumer().current.filter(type, target);
	}

	private void handle(BaseConsumers cons, CollectionObjectMap<ConsumeType<?>, Set<Content>> map) {
		for (BaseConsume<?> c : cons.all()) {
			if ((c.filter()) != null) {
				Set<Content> all = allFilter.get(c.type(), createSet);
				Set<Content> set = map.get(c.type(), createSet);
				for (Content o : c.filter()) {
					set.add(o);
					all.add(o);
				}
			}
		}
	}
}
