package heavyindustry.world.misc.cons;

import heavyindustry.util.CollectionList;
import mindustry.ctype.ContentType;

@SuppressWarnings("unchecked")
public class ConsumeType<T extends BaseConsume<?>> {
	private static final CollectionList<ConsumeType<?>> allType = new CollectionList<>(ConsumeType.class);

	public static final ConsumeType<ConsumePower<?>> power = (ConsumeType<ConsumePower<?>>) add(ConsumePower.class, null);
	public static final ConsumeType<ConsumeItemBase<?>> item = (ConsumeType<ConsumeItemBase<?>>) add(ConsumeItemBase.class, ContentType.item);
	public static final ConsumeType<ConsumeLiquidBase<?>> liquid = (ConsumeType<ConsumeLiquidBase<?>>) add(ConsumeLiquidBase.class, ContentType.liquid);
	public static final ConsumeType<ConsumePayload<?>> payload = (ConsumeType<ConsumePayload<?>>) add(ConsumePayload.class, null);

	private final int id;
	private final Class<T> type;
	private final ContentType contType;

	public ConsumeType(Class<T> type, ContentType cType) {
		id = allType.size;
		this.type = type;
		contType = cType;
		allType.add(this);
	}

	public Class<T> getType() {
		return type;
	}

	public final ContentType cType() {
		return contType;
	}

	public final int id() {
		return id;
	}

	public static ConsumeType<?>[] all() {
		return allType.toArray();
	}

	public static <T extends BaseConsume<?>> ConsumeType<? extends T> add(Class<T> type, ContentType contentType) {
		return new ConsumeType<>(type, contentType);
	}
}
