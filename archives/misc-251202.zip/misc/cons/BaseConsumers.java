package heavyindustry.world.misc.cons;

import arc.func.Boolf;
import arc.func.Cons;
import arc.func.Cons2;
import arc.func.Floatf;
import arc.func.Prov;
import arc.scene.event.Touchable;
import arc.util.Time;
import heavyindustry.util.CollectionList;
import heavyindustry.util.CollectionObjectMap;
import heavyindustry.util.CollectionObjectSet;
import heavyindustry.world.misc.ConsumerBlockComp.ConsumerBuildComp;
import mindustry.ctype.Content;
import mindustry.gen.Building;
import mindustry.type.Item;
import mindustry.type.ItemStack;
import mindustry.type.Liquid;
import mindustry.type.LiquidStack;
import mindustry.world.meta.Stat;
import mindustry.world.meta.StatUnit;
import mindustry.world.meta.Stats;

import java.util.List;
import java.util.Set;

/**
 * A consumption list that records all information related to consumption, including production time, options, etc.
 *
 * @author EBwilson
 */
public class BaseConsumers {
	protected static final CollectionList<BaseConsume<?>> tmpCons = new CollectionList<>(BaseConsume.class);

	protected final CollectionObjectMap<ConsumeType<?>, BaseConsume<?>> cons = new CollectionObjectMap<>(ConsumeType.class, BaseConsume.class);

	/** This value controls the time consumed in production. */
	public float craftTime = 60;
	/** Whether to display the time required for consumption in the statistics column. */
	public boolean showTime = false;

	/** Is it an optional consumable item. */
	public final boolean optional;
	public boolean optionalAlwaysValid = true;

	/** The objective function to be executed with updates when the optional list is available. */
	public Cons2<ConsumerBuildComp, BaseConsumers> optionalDef = (entity, cons) -> {};
	/** Function for displaying custom content in statistical information. */
	public Cons2<Stats, BaseConsumers> display = (stats, cons) -> {};
	/** Do you want to overwrite the default item display with a custom display. */
	public boolean customDisplayOnly;

	public Prov<Visibility> selectable = () -> Visibility.usable;

	public Floatf<ConsumerBuildComp> consDelta = e -> e.getBuilding().delta() * e.consEfficiency();
	/** The available controllers for this consumption. */
	public List<Boolf<ConsumerBuildComp>> valid = new CollectionList<>(Boolf.class);
	/** Consuming triggers, triggered when the consumed trigger() method is executed. */
	public List<Cons<ConsumerBuildComp>> triggers = new CollectionList<>(Cons.class);

	protected final CollectionObjectMap<ConsumeType<?>, Set<Content>> filter = new CollectionObjectMap<>(ConsumeType.class, Set.class);
	protected final CollectionObjectMap<ConsumeType<?>, Set<Content>> otherFilter = new CollectionObjectMap<>(ConsumeType.class, Set.class);
	protected final CollectionObjectMap<ConsumeType<?>, Set<Content>> selfAccess = new CollectionObjectMap<>(ConsumeType.class, Set.class);

	protected final Prov<Set<Content>> createSet = () -> new CollectionObjectSet<>(Content.class);

	public BaseConsumers(boolean optional) {
		this.optional = optional;
	}

	public void initFilter() {
		filter.clear();
		for (var entry : cons) {
			List<Content> cont = entry.value.filter();
			if (cont != null) filter.get(entry.key, createSet).addAll(cont);
		}
		for (var entry : otherFilter) {
			filter.get(entry.key, createSet).addAll(entry.value);
		}
	}

	public void addToFilter(ConsumeType<?> type, Content content) {
		otherFilter.get(type, createSet).add(content);
	}

	public void addSelfAccess(ConsumeType<?> type, Content content) {
		selfAccess.get(type, createSet).add(content);
	}

	public BaseConsumers time(float time) {
		craftTime = time;
		showTime = time > 0;
		return this;
	}

	public BaseConsumers overdriveValid(boolean valid) {
		consDelta = valid ?
				e -> e.getBuilding().delta() * e.consEfficiency() :
				e -> Time.delta * e.consEfficiency();
		return this;
	}

	@SuppressWarnings("unchecked")
	public <T extends ConsumerBuildComp> BaseConsumers setConsDelta(Floatf<T> delta) {
		consDelta = (Floatf<ConsumerBuildComp>) delta;
		return this;
	}

	@SuppressWarnings("unchecked")
	public <T extends ConsumerBuildComp> BaseConsumers consValidCondition(Boolf<T> cond) {
		valid.add((Boolf<ConsumerBuildComp>) cond);
		return this;
	}

	@SuppressWarnings("unchecked")
	public <T extends ConsumerBuildComp> BaseConsumers setConsTrigger(Cons<T> cond) {
		triggers.add((Cons<ConsumerBuildComp>) cond);
		return this;
	}

	public float delta(ConsumerBuildComp entity) {
		return optional ? entity.getBuilding().delta() * entity.optionalConsEff(this) * Math.max(1, entity.consEfficiency()) : consDelta.get(entity);
	}

	public ConsumeItems<? extends ConsumerBuildComp> item(Item item, int amount) {
		return items(new ItemStack(item, amount));
	}

	public ConsumeItems<? extends ConsumerBuildComp> items(ItemStack... items) {
		return add(new ConsumeItems<>(items));
	}

	public ConsumeLiquids<? extends ConsumerBuildComp> liquid(Liquid liquid, float amount) {
		return liquids(new LiquidStack(liquid, amount));
	}

	public ConsumeLiquids<? extends ConsumerBuildComp> liquids(LiquidStack... liquids) {
		return add(new ConsumeLiquids<>(liquids));
	}

	public ConsumePower<? extends ConsumerBuildComp> power(float usage) {
		return add(new ConsumePower<>(usage, 0));
	}

	public ConsumePower<? extends ConsumerBuildComp> power(float usage, float capacity) {
		return add(new ConsumePower<>(usage, capacity));
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	public <T extends ConsumerBuildComp> ConsumePower<?> powerCond(float usage, float capacity, Boolf<T> cons) {
		return add(new ConsumePower(usage, capacity) {
			@Override
			public float requestedPower(Building entity) {
				return ((Boolf) cons).get(entity) ? super.requestedPower(entity) : 0f;
			}
		});
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	public <T extends ConsumerBuildComp> ConsumePower<?> powerDynamic(Floatf<T> cons, float capacity, Cons<Stats> statBuilder) {
		return add(new ConsumePower(0, capacity) {
			@Override
			public float requestedPower(Building entity) {
				return ((Floatf) cons).get(entity);
			}

			@Override
			public void display(Stats stats) {
				statBuilder.get(stats);
			}
		});
	}

	public ConsumePower<? extends ConsumerBuildComp> powerBuffer(float usage, float capacity) {
		return add(new ConsumePower<>(usage, capacity));
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	public <T extends BaseConsume<? extends ConsumerBuildComp>> T add(T consume) {
		BaseConsume c = cons.get(consume.type());
		if (c == null) {
			cons.put(consume.type(), consume);
			consume.parent = this;
			return consume;
		} else {
			c.merge(consume);
		}
		return (T) c;
	}

	@SuppressWarnings("unchecked")
	public <T extends BaseConsume<? extends ConsumerBuildComp>> T get(ConsumeType<T> type) {
		return (T) cons.get(type);
	}

	public Iterable<BaseConsume<? extends ConsumerBuildComp>> all() {
		tmpCons.clear();

		for (ConsumeType<?> type : ConsumeType.all()) {
			BaseConsume<?> c = cons.get(type);
			if (c != null) tmpCons.add(c);
		}

		return tmpCons;
	}

	public void remove(ConsumeType<?> type) {
		cons.remove(type);
	}

	public void display(Stats stats) {
		if (cons.size > 0 && !customDisplayOnly) {
			if (showTime) stats.add(Stat.productionTime, craftTime / 60f, StatUnit.seconds);
			for (BaseConsume<?> c : all()) {
				c.display(stats);
			}
		}

		display.get(stats, this);
	}

	public boolean filter(ConsumeType<?> type, Content content) {
		return filter.get(type, createSet).contains(content);
	}

	public boolean selfAccess(ConsumeType<?> type, Content content) {
		return selfAccess.get(type, createSet).contains(content);
	}

	public enum Visibility {
		usable(Touchable.enabled),
		unusable(Touchable.disabled),
		hidden(Touchable.disabled);

		public final Touchable buttonValid;

		public static final Visibility[] all = values();

		Visibility(Touchable touchable) {
			buttonValid = touchable;
		}
	}
}
